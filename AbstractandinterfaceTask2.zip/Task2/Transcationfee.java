package Task2;

public interface Transcationfee {
public  double Fee = 0;
	
	 void applyTransactionFee(double fee);
}
