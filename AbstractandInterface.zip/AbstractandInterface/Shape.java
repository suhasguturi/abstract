package AbstractandInterface;

public interface Shape {
	
	

	String getcoloroftheshape = null;
	public abstract double area ();
	public abstract 	double perimeter();

}
